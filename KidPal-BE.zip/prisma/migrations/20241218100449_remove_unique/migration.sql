-- DropIndex
DROP INDEX `Otp_userId_key` ON `Otp`;
